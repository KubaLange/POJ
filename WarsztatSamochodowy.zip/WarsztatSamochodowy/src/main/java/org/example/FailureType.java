package org.example;

public enum FailureType {
    ENGINE_FAILURE, WHEELS_FAILURE, BODY_FAILURE;
}
